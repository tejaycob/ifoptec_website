## Grunt

The `plugins.min.js` & `warehouse.min.js` files along with their source maps are generated using [Grunt](https://gruntjs.com/getting-started) (see `package.json` & `Gruntfile.js` files at the root of this project).


## Copyright

See each JS file or plugin subfolder for their respective copyrights.
