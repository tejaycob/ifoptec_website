<?php

require_once 'modules/Food_Service/includes/FS_Icons.inc.php';

$_REQUEST['cat_id'] = issetVal( $_REQUEST['cat_id'] );

DrawHeader( ProgramTitle() );

$menus_RET = DBGet( "SELECT MENU_ID,TITLE
	FROM FOOD_SERVICE_MENUS
	WHERE SCHOOL_ID='" . UserSchool() . "'
	ORDER BY SORT_ORDER", array(), array( 'MENU_ID' ) );

if ( ! empty( $_REQUEST['menu_id'] ) )
{
	if ( $_REQUEST['menu_id'] !== 'new' )
	{
		if ( $menus_RET[$_REQUEST['menu_id']] )
		{
			$_SESSION['FSA_menu_id'] = $_REQUEST['menu_id'];
		}
		elseif ( ! empty( $menus_RET ) )
		{
			$_REQUEST['menu_id'] = $_SESSION['FSA_menu_id'] = key( $menus_RET );
		}
		else
		{
			ErrorMessage( array( _( 'There are no menus yet setup.' ) ), 'fatal' );
		}
	}
	elseif ( ! empty( $menus_RET ) )
	{
		$_REQUEST['menu_id'] = $_SESSION['FSA_menu_id'] = key( $menus_RET );
	}
	else
	{
		ErrorMessage( array( _( 'There are no menus yet setup.' ) ), 'fatal' );
	}
}
else
{
	if ( $_SESSION['FSA_menu_id'] )
	{
		if ( $menus_RET[$_SESSION['FSA_menu_id']] )
		{
			$_REQUEST['menu_id'] = $_SESSION['FSA_menu_id'];
		}
		elseif ( ! empty( $menus_RET ) )
		{
			$_REQUEST['menu_id'] = $_SESSION['FSA_menu_id'] = key( $menus_RET );
		}
		else
		{
			ErrorMessage( array( _( 'There are no menus yet setup.' ) ), 'fatal' );
		}
	}
	elseif ( ! empty( $menus_RET ) )
	{
		$_REQUEST['menu_id'] = $_SESSION['FSA_menu_id'] = key( $menus_RET );
	}
	else
	{
		ErrorMessage( array( _( 'There are no menus yet setup.' ) ), 'fatal' );
	}
}

$categories_RET = DBGet( "SELECT MENU_ID,CATEGORY_ID,TITLE
	FROM FOOD_SERVICE_CATEGORIES
	WHERE SCHOOL_ID='" . UserSchool() . "'
	ORDER BY SORT_ORDER", array(), array( 'MENU_ID', 'CATEGORY_ID' ) );
//FJ fix error Warning: key() expects parameter 1 to be array, null given
//if ( ! $_REQUEST['cat_id'] || ! $categories_RET[$_REQUEST['menu_id']][$_REQUEST['cat_id']])

if ( ( ! $_REQUEST['cat_id'] || ! $categories_RET[$_REQUEST['menu_id']][$_REQUEST['cat_id']] ) && isset( $categories_RET[$_REQUEST['menu_id']] ) )
{
	$_REQUEST['cat_id'] = key( $categories_RET[$_REQUEST['menu_id']] );
}

$meals = array();

foreach ( (array) $menus_RET as $id => $menu )
{
	$meals[] = array(
		'title' => $menu[1]['TITLE'],
		'link' => 'Modules.php?modname=' . $_REQUEST['modname'] . '&menu_id=' . $id,
	);
}

$cats = array();
//FJ fix error Warning: Invalid argument supplied for foreach()

if ( isset( $categories_RET[$_REQUEST['menu_id']] ) )
{
	foreach ( (array) $categories_RET[$_REQUEST['menu_id']] as $category_id => $category )
	{
		$cats[ $category_id ] = array(
			'title' => $category[1]['TITLE'],
			'link' => 'Modules.php?modname=' . $_REQUEST['modname'] . '&menu_id=' . $_REQUEST['menu_id'] .
				'&cat_id=' . $category_id,
		);
	}
}

$items_RET = DBGet( "SELECT (SELECT DESCRIPTION FROM FOOD_SERVICE_ITEMS WHERE ITEM_ID=fsmi.ITEM_ID) AS DESCRIPTION,
	(SELECT ICON FROM FOOD_SERVICE_ITEMS WHERE ITEM_ID=fsmi.ITEM_ID) AS ICON
FROM FOOD_SERVICE_MENU_ITEMS fsmi
WHERE MENU_ID='" . $_REQUEST['menu_id'] . "'
AND CATEGORY_ID='" . $_REQUEST['cat_id'] . "'
ORDER BY (SELECT SORT_ORDER FROM FOOD_SERVICE_CATEGORIES WHERE CATEGORY_ID=fsmi.CATEGORY_ID),SORT_ORDER" );

echo '<br />';

$_ROSARIO['selected_tab'] = 'Modules.php?modname=' . $_REQUEST['modname'] . '&menu_id=' . $_REQUEST['menu_id'];

PopTable( 'header', $meals );

if ( ! empty( $items_RET ) )
{
	$per_row = ceil( sqrt( count( $items_RET ) ) );

	echo '<table class="center cellpadding-5">';

	$i = 0;

	foreach ( (array) $items_RET as $item )
	{
		if ( ! $i )
		{
			echo '<tr>';
			$i = $per_row;
		}

		echo '<td style="border: 1px solid" title="' . $item['DESCRIPTION'] . '">' .
			makeIcon( $item['ICON'], '', '128' ) . '</td>';
		$i--;

		if ( ! $i )
		{
			echo '</tr>';
		}
	}

	if ( $i )
	{
		echo '</tr>';
	}

	echo '</table>';
}

echo '<br /><div class="center">';

$i = 0;

if ( count( $cats ) === 1 )
{
	$cat = reset( $cats );

	echo $cat['title'];
}
else
{
	foreach ( $cats as $cat_id => $cat )
	{
		if ( $i++ > 0 )
		{
			echo ' | ';
		}

		echo '<a href="' . $cat['link'] . '">' .
			( $_REQUEST['cat_id'] == $cat_id ? '<b>' . $cat['title'] . '</b>' : $cat['title'] ) .
			'</a>';
	}
}

echo '</div>';

PopTable( 'footer' );
