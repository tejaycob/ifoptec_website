<?php

require_once 'ProgramFunctions/MarkDownHTML.fnc.php';
require_once 'modules/School_Setup/includes/CalendarDay.inc.php';

DrawHeader( ProgramTitle() );

// Set Month.
if ( ! isset( $_REQUEST['month'] )
	|| mb_strlen( $_REQUEST['month'] ) !== 2 )
{
	$_REQUEST['month'] = date( 'm' );
}

// Set Year.
if ( ! isset( $_REQUEST['year'] )
	|| mb_strlen( $_REQUEST['year'] ) !== 4 )
{
	$_REQUEST['year'] = date( 'Y' );
}

if ( isset( $_REQUEST['calendar_id'] ) )
{
	$_REQUEST['calendar_id'] = (string) (int) $_REQUEST['calendar_id'];
}

// Create / Recreate Calendar.
if ( $_REQUEST['modfunc'] === 'create'
	&& AllowEdit() )
{
	$fy_RET = DBGet( "SELECT START_DATE,END_DATE
		FROM SCHOOL_MARKING_PERIODS
		WHERE MP='FY'
		AND SCHOOL_ID='" . UserSchool() . "'
		AND SYEAR='" . UserSyear() . "'" );

	$fy = $fy_RET[1];

	// Get Calendars Info.
	$title_RET = DBGet( "SELECT ac.CALENDAR_ID,ac.TITLE,ac.DEFAULT_CALENDAR,ac.SCHOOL_ID,
		(SELECT coalesce(SHORT_NAME,TITLE)
			FROM SCHOOLS
			WHERE SYEAR=ac.SYEAR
			AND ID=ac.SCHOOL_ID) AS SCHOOL_TITLE,
		(SELECT min(SCHOOL_DATE)
			FROM ATTENDANCE_CALENDAR
			WHERE CALENDAR_ID=ac.CALENDAR_ID) AS START_DATE,
		(SELECT max(SCHOOL_DATE)
			FROM ATTENDANCE_CALENDAR
			WHERE CALENDAR_ID=ac.CALENDAR_ID) AS END_DATE
		FROM ATTENDANCE_CALENDARS ac,STAFF s
		WHERE ac.SYEAR='" . UserSyear() . "'
		AND s.STAFF_ID='" . User( 'STAFF_ID' ) . "'
		AND (s.SCHOOLS IS NULL OR position(','||ac.SCHOOL_ID||',' IN s.SCHOOLS)>0)
		ORDER BY " . db_case( array( 'ac.SCHOOL_ID', "'" . UserSchool() . "'", 0, 'ac.SCHOOL_ID' ) ) . ",ac.DEFAULT_CALENDAR ASC,ac.TITLE" );

	// Prepare table for Copy Calendar & add ' (Default)' mention.
	$copy_calendar_options = array();

	$recreate_calendar = false;

	foreach ( (array) $title_RET as $title )
	{
		$copy_calendar_options[ $title['CALENDAR_ID'] ] = $title['TITLE'];

		if ( AllowEdit()
			&& $title['DEFAULT_CALENDAR'] === 'Y'
			&& $title['SCHOOL_ID'] === UserSchool() )
		{
			$copy_calendar_options[ $title['CALENDAR_ID'] ] .= ' (' . _( 'Default' ) . ')';
		}

		if ( AllowEdit()
			&& isset( $_REQUEST['calendar_id'] )
			&& $title['CALENDAR_ID'] == $_REQUEST['calendar_id'] )
		{
			$recreate_calendar = $title;
		}
	}

	$div = false;

	$message = '<table class="width-100p valign-top"><tr class="st"><td>';

	// Title.
	$message .= TextInput(
		( $recreate_calendar ? $recreate_calendar['TITLE'] : '' ),
		'title',
		_( 'Title' ),
		'required maxlength="100"',
		$div
	);

	$message .= '</td><td>';

	// Default.
	$message .= CheckboxInput(
		$recreate_calendar && $recreate_calendar['DEFAULT_CALENDAR'] == 'Y',
		'default',
		_( 'Default Calendar for this School' ),
		'',
		true
	);

	$message .= '</td><td>';

	// Copy calendar.
	$message .= SelectInput(
		empty( $_REQUEST['calendar_id'] ) ? '' : $_REQUEST['calendar_id'],
		'copy_id',
		_( 'Copy Calendar' ),
		$copy_calendar_options,
		'N/A',
		'',
		$div
	);

	$message .= '</td></tr></table>';

	// From date.
	$message .= '<table class="width-100p valign-top"><tr class="st"><td>' . _( 'From' ) . ' ';

	$message .= DateInput(
		$recreate_calendar && $recreate_calendar['START_DATE'] ?
			$recreate_calendar['START_DATE'] :
			$fy['START_DATE'],
		'min',
		'',
		$div,
		true,
		!( $recreate_calendar && $recreate_calendar['START_DATE'] )
	);

	// to date
	$message .= '</td><td>' . _( 'To' )  . ' ';
	$message .= DateInput(
		$recreate_calendar && $recreate_calendar['END_DATE'] ?
			$recreate_calendar['END_DATE'] :
			$fy['END_DATE'],
		'max',
		'',
		$div,
		true,
		!( $recreate_calendar && $recreate_calendar['END_DATE'] )
	);

	$message .= '</td></tr></table>';

	$message .= '<table class="width-100p valign-top"><tr class="st"><td>';

	// Weekdays.
	$weekdays = array(
		_( 'Sunday' ),
		_( 'Monday' ),
		_( 'Tuesday' ),
		_( 'Wednesday' ),
		_( 'Thursday' ),
		_( 'Friday' ),
		_( 'Saturday' ),
	);

	$weekdays_inputs = array();

	foreach ( (array) $weekdays as $id => $weekday )
	{
		$value = 'Y';

		// Unckeck Saturday & Sunday.
		if ( ( $id === 0
				|| $id === 6 )
			&& ! $recreate_calendar )
		{
			$value = 'N';
		}

		$weekdays_inputs[] .= CheckboxInput(
			$value,
			'weekdays[' . $id . ']',
			$weekday,
			'',
			true
		);
	}

	$message .= implode( '</td><td>', $weekdays_inputs );

	$message .= '</td></tr></table>';

	$message .= '<table class="width-100p"><tr class="st valign-top"><td>';

	// minutes
	$minutes_tip_text = ( $recreate_calendar ?
		_( 'Default is Full Day if Copy Calendar is N/A.' ) . ' ' . _( 'Otherwise Default is minutes from the Copy Calendar' ) :
		_( 'Default is Full Day' )
	);

	$message .= TextInput(
		'',
		'minutes',
		_( 'Minutes' ) .
			'<div class="tooltip"><i>' . $minutes_tip_text . '</i></div>',
		'size="3" maxlength="3"',
		$div
	);

	$message .= '</td></tr></table>';

	$OK = Prompt(
		! empty( $_REQUEST['calendar_id'] ) ?
		sprintf( _( 'Recreate %s calendar' ), $recreate_calendar['TITLE'] ) :
		_( 'Create new calendar' ),
		'',
		$message
	);

	// If Confirm Create / Recreate
	if ( $OK )
	{
		// Set Calendar ID
		if ( ! empty( $_REQUEST['calendar_id'] ) )
		{
			$calendar_id = $_REQUEST['calendar_id'];
		}
		else
		{
			$calendar_id = DBSeqNextID( 'attendance_calendars_calendar_id_seq' );
		}

		if ( ! empty( $_REQUEST['default'] ) )
		{
			DBQuery( "UPDATE ATTENDANCE_CALENDARS
				SET DEFAULT_CALENDAR=NULL
				WHERE SYEAR='" . UserSyear() . "'
				AND SCHOOL_ID='" . UserSchool() . "'" );
		}

		// Recreate
		if ( ! empty( $_REQUEST['calendar_id'] ) )
		{
			DBQuery( "UPDATE ATTENDANCE_CALENDARS
				SET TITLE='" . $_REQUEST['title'] . "',DEFAULT_CALENDAR='" . $_REQUEST['default'] . "'
				WHERE CALENDAR_ID='" . $calendar_id . "'" );
		}
		// Create
		else
		{
			DBQuery( "INSERT INTO ATTENDANCE_CALENDARS
				(CALENDAR_ID,SYEAR,SCHOOL_ID,TITLE,DEFAULT_CALENDAR)
				values('" . $calendar_id . "','" . UserSyear() . "','" . UserSchool() . "','" . $_REQUEST['title'] . "','" . $_REQUEST['default'] . "')" );
		}

		//FJ fix bug MINUTES not numeric
		$minutes = '999';

		if ( isset( $_REQUEST['minutes'] )
			&& intval( $_REQUEST['minutes'] ) > 0 )
		{
			$minutes = intval( $_REQUEST['minutes'] );
		}

		// Copy Calendar
		if ( ! empty( $_REQUEST['copy_id'] ) )
		{
			$weekdays_list = array();

			// FJ remove empty weekdays.
			foreach ( (array) $_REQUEST['weekdays'] as $weekday_id => $yes )
			{
				if ( $yes )
				{
					$weekdays_list[] = $weekday_id;
				}
			}

			$weekdays_list = "'" . implode( "','", $weekdays_list ) . "'";

			$date_min = RequestedDate( 'min', '' );

			$date_max = RequestedDate( 'max', '' );

			if ( $_REQUEST['calendar_id']
				&& $_REQUEST['calendar_id'] === $_REQUEST['copy_id'] )
			{
				DBQuery( "DELETE FROM ATTENDANCE_CALENDAR
					WHERE CALENDAR_ID='" . $calendar_id . "'
					AND (SCHOOL_DATE NOT BETWEEN '" . $date_min . "' AND '" . $date_max . "'
						OR extract(DOW FROM SCHOOL_DATE) NOT IN (" . $weekdays_list . "))" );

				if ( $minutes != '999' )
				{
					DBQuery( "UPDATE ATTENDANCE_CALENDAR
						SET MINUTES='" . $minutes . "'
						WHERE CALENDAR_ID='" . $calendar_id . "'" );
				}
			}
			else
			{
				if ( ! empty( $_REQUEST['calendar_id'] ) )
				{
					DBQuery( "DELETE FROM ATTENDANCE_CALENDAR
						WHERE CALENDAR_ID='" . $calendar_id . "'" );
				}

				// Insert Days.
				$create_calendar_sql = "INSERT INTO ATTENDANCE_CALENDAR
					(SYEAR,SCHOOL_ID,SCHOOL_DATE,MINUTES,CALENDAR_ID)
					(SELECT '" . UserSyear() . "','" . UserSchool() . "',SCHOOL_DATE," . $minutes . ",'" . $calendar_id . "'
						FROM ATTENDANCE_CALENDAR
						WHERE CALENDAR_ID='" . $_REQUEST['copy_id'] . "'
						AND extract(DOW FROM SCHOOL_DATE) IN (" . $weekdays_list . ")";

				if ( $date_min && $date_max )
				{
					$create_calendar_sql .= " AND SCHOOL_DATE
						BETWEEN '" . $date_min . "'
						AND '" . $date_max . "'";
				}

				$create_calendar_sql .= ")";

				DBQuery( $create_calendar_sql );
			}
		}
		// Create Calendar
		else
		{
			$begin = mktime(0,0,0,$_REQUEST['month_min'],$_REQUEST['day_min']*1,$_REQUEST['year_min']) + 43200;

			$end = mktime(0,0,0,$_REQUEST['month_max'],$_REQUEST['day_max']*1,$_REQUEST['year_max']) + 43200;

			$weekday = date( 'w', $begin );

			if ( ! empty( $_REQUEST['calendar_id'] ) )
			{
				DBQuery( "DELETE FROM ATTENDANCE_CALENDAR
					WHERE CALENDAR_ID='" . $calendar_id . "'" );
			}

			$sql_calendar_days = '';

			// Insert Days.
			for ( $i = $begin; $i <= $end; $i += 86400 )
			{
				if ( $_REQUEST['weekdays'][ $weekday ] == 'Y' )
				{
					$sql_calendar_days .= "INSERT INTO ATTENDANCE_CALENDAR
						(SYEAR,SCHOOL_ID,SCHOOL_DATE,MINUTES,CALENDAR_ID)
						VALUES('" . UserSyear() . "','" . UserSchool() . "','" . date( 'Y-m-d', $i ) . "'," . $minutes . ",'" . $calendar_id . "');";
				}

				$weekday++;

				if ( $weekday == 7 )
					$weekday = 0;
			}

			if ( $sql_calendar_days )
			{
				DBQuery( $sql_calendar_days );
			}
		}

		// Set Current Calendar
		$_REQUEST['calendar_id'] = $calendar_id;

		// Unset modfunc & weekdays & title & minutes & copy ID & redirect URL.
		RedirectURL( array( 'modfunc', 'weekdays', 'title', 'minutes', 'copy_id' ) );
	}
}

// Delete Calendar
if ( $_REQUEST['modfunc'] === 'delete_calendar'
	&& AllowEdit() )
{
	if ( DeletePrompt( _( 'Calendar' ) ) )
	{
		$delete_sql = "DELETE FROM ATTENDANCE_CALENDAR
			WHERE CALENDAR_ID='" . $_REQUEST['calendar_id'] . "';";

		$delete_sql .= "DELETE FROM ATTENDANCE_CALENDARS
			WHERE CALENDAR_ID='" . $_REQUEST['calendar_id'] . "';";

		DBQuery( $delete_sql );

		$default_RET = DBGet( "SELECT CALENDAR_ID
			FROM ATTENDANCE_CALENDARS
			WHERE SYEAR='" . UserSyear() . "'
			AND SCHOOL_ID='" . UserSchool() . "'
			AND DEFAULT_CALENDAR='Y'" );

		// Unset modfunc & calendar ID & redirect URL.
		RedirectURL( array( 'modfunc', 'calendar_id' ) );
	}
}

// Set non admin Current Calendar.
if ( User( 'PROFILE' ) !== 'admin'
	&& UserCoursePeriod() )
{
	$calendar_id = DBGetOne( "SELECT CALENDAR_ID
		FROM COURSE_PERIODS
		WHERE COURSE_PERIOD_ID='" . UserCoursePeriod() . "'" );

	if ( $calendar_id )
	{
		$_REQUEST['calendar_id'] = $calendar_id;
	}
}

// Set Current Calendar.
if ( ! isset( $_REQUEST['calendar_id'] )
	|| intval( $_REQUEST['calendar_id'] ) < 1 )
{
	$default_calendar_id = DBGetOne( "SELECT CALENDAR_ID
		FROM ATTENDANCE_CALENDARS
		WHERE SYEAR='" . UserSyear() . "'
		AND SCHOOL_ID='" . UserSchool() . "'
		AND DEFAULT_CALENDAR='Y'" );

	if ( $default_calendar_id )
	{
		$_REQUEST['calendar_id'] = $default_calendar_id;
	}
	else
	{
		$calendar_id = DBGetOne( "SELECT CALENDAR_ID
			FROM ATTENDANCE_CALENDARS
			WHERE SYEAR='" . UserSyear() . "'
			AND SCHOOL_ID='" . UserSchool() . "'" );

		if ( $calendar_id )
		{
			$_REQUEST['calendar_id'] = $calendar_id;
		}
		else
			$no_calendars_error[] = _( 'There are no calendars setup yet.' );
	}
}

unset( $_SESSION['_REQUEST_vars']['calendar_id'] );

// Event / Assignment details
if ( $_REQUEST['modfunc'] === 'detail' )
{
	AddRequestedDates( 'values' );

	if ( isset( $_POST['button'] )
		&& $_POST['button'] === _( 'Save' )
		&& AllowEdit() )
	{
		if ( ! empty( $_REQUEST['values'] ) )
		{
			// FJ textarea fields MarkDown sanitize.
			if ( ! empty( $_REQUEST['values']['DESCRIPTION'] ) )
			{
				$_REQUEST['values']['DESCRIPTION'] = SanitizeMarkDown( $_POST['values']['DESCRIPTION'] );
			}

			// Update Event.
			if ( $_REQUEST['event_id'] !== 'new' )
			{
				$sql = "UPDATE CALENDAR_EVENTS SET ";

				foreach ( (array) $_REQUEST['values'] as $column => $value )
				{
					$sql .= DBEscapeIdentifier( $column ) . "='" . $value . "',";
				}

				$sql = mb_substr( $sql, 0, -1 ) . " WHERE ID='" . $_REQUEST['event_id'] . "'";

				DBQuery( $sql );

				// Hook.
				do_action('School_Setup/Calendar.php|update_calendar_event');
			}
			// Create Event.
			else
			{
				// FJ add event repeat.
				$i = 0;

				do {
					if ( $i > 0 ) // School date + 1 day.
					{
						$_REQUEST['values']['SCHOOL_DATE'] = date(
							'd-M-Y',
							mktime( 0, 0, 0,
								$_REQUEST['month_values']['SCHOOL_DATE'],
 								$_REQUEST['day_values']['SCHOOL_DATE'] + $i,
								$_REQUEST['year_values']['SCHOOL_DATE']
							)
 						);
					}

					$sql = "INSERT INTO CALENDAR_EVENTS ";

					$fields = 'ID,SYEAR,SCHOOL_ID,';

					$calendar_event_id = DBSeqNextID( 'calendar_events_id_seq' );

					$values = $calendar_event_id . ",'" . UserSyear() . "','" . UserSchool() . "',";

					$go = false;

					foreach ( (array) $_REQUEST['values'] as $column => $value )
					{
						if ( ! empty( $value )
							|| $value == '0' )
						{
							$fields .= $column . ',';
							$values .= "'" . $value . "',";
							$go = true;
						}
					}

					$sql .= '(' . mb_substr( $fields, 0, -1 ) . ') values(' . mb_substr( $values, 0, -1 ) . ')';

					if ( $go )
					{
						DBQuery( $sql );

						// Hook.
						do_action( 'School_Setup/Calendar.php|create_calendar_event' );
					}

					$i++;

				} while( is_numeric( $_REQUEST['REPEAT'] )
					&& $i <= $_REQUEST['REPEAT'] );
			}

			// Reload Calendar & close popup
			$opener_URL = "Modules.php?modname=" . $_REQUEST['modname'] . "&year=" . $_REQUEST['year'] . "&month=" . $_REQUEST['month'];
			?>
<script>
	window.opener.ajaxLink(<?php echo json_encode( $opener_URL ); ?>);
	window.close();
</script>
			<?php

			// Unset values & redirect URL.
			RedirectURL( 'values' );
		}
	}
	// Delete Event
	elseif ( isset( $_REQUEST['button'] )
		&& $_REQUEST['button'] == _( 'Delete' )
		&& ! isset( $_REQUEST['delete_cancel'] ) )
	{
		if ( DeletePrompt( _( 'Event' ), 'Delete', false ) )
		{
			DBQuery( "DELETE FROM CALENDAR_EVENTS
				WHERE ID='" . $_REQUEST['event_id'] . "'" );

			//hook
			do_action( 'School_Setup/Calendar.php|delete_calendar_event' );

			// Reload Calendar & close popup
			$opener_URL = "Modules.php?modname=" . $_REQUEST['modname'] . "&year=" . $_REQUEST['year'] . "&month=" . $_REQUEST['month'];
			?>
<script>
	window.opener.ajaxLink(<?php echo json_encode( $opener_URL ); ?>);
	window.close();
</script>
			<?php

			// Unset button & values & redirect URL.
			RedirectURL( array( 'button', 'values' ) );
		}
	}
	// Display Event / Assignment
	else
	{
		// Event
		if ( ! empty( $_REQUEST['event_id'] ) )
		{
			if ( $_REQUEST['event_id'] !== 'new' )
			{
				$RET = DBGet( "SELECT TITLE,DESCRIPTION,SCHOOL_DATE
					FROM CALENDAR_EVENTS
					WHERE ID='" . $_REQUEST['event_id'] . "'" );

				$title = $RET[1]['TITLE'];
			}
			else
			{
				//FJ add translation
				$title = _( 'New Event' );

				$RET[1]['SCHOOL_DATE'] = issetVal( $_REQUEST['school_date'] );
			}

			echo '<form action="Modules.php?modname=' . $_REQUEST['modname'] . '&modfunc=detail&event_id=' . $_REQUEST['event_id'] . '&month=' . $_REQUEST['month'] . '&year=' . $_REQUEST['year'] . '" method="POST">';
		}
		// Assignment
		elseif ( ! empty( $_REQUEST['assignment_id'] ) )
		{
			//FJ add assigned date
			$RET = DBGet( "SELECT a.TITLE,a.STAFF_ID,a.DUE_DATE AS SCHOOL_DATE,
				a.DESCRIPTION,a.ASSIGNED_DATE,c.TITLE AS COURSE,a.SUBMISSION
				FROM GRADEBOOK_ASSIGNMENTS a,COURSES c
				WHERE (a.COURSE_ID=c.COURSE_ID
					OR c.COURSE_ID=(SELECT cp.COURSE_ID
						FROM COURSE_PERIODS cp
						WHERE cp.COURSE_PERIOD_ID=a.COURSE_PERIOD_ID))
				AND a.ASSIGNMENT_ID='" . $_REQUEST['assignment_id'] . "'" );

			$title = $RET[1]['TITLE'];

			$RET[1]['STAFF_ID'] = GetTeacher( $RET[1]['STAFF_ID'] );
		}

		echo '<br />';

		PopTable( 'header', $title );

		echo '<table class="cellpadding-5"><tr><td>' .
			DateInput( $RET[1]['SCHOOL_DATE'], 'values[SCHOOL_DATE]', _( 'Date' ), false ) .
		'</td></tr>';

		// Add assigned date.
		if ( ! empty( $RET[1]['ASSIGNED_DATE'] ) )
		{
			echo '<tr><td>' .
				DateInput( $RET[1]['ASSIGNED_DATE'], 'values[ASSIGNED_DATE]', _( 'Assigned Date' ), false ) .
			'</td></tr>';
		}

		// Add submit Assignment link.
		if ( ! empty( $RET[1]['SUBMISSION'] )
			&& AllowUse( 'Grades/StudentAssignments.php' ) )
		{
			echo '<tr><td>
				<a href="Modules.php?modname=Grades/StudentAssignments.php&assignment_id=' .
					$_REQUEST['assignment_id'] . '" onclick="window.opener.ajaxLink(this.href); window.close();">' .
				_( 'Submit Assignment' ) .
			'</a></td></tr>';
		}

		// FJ add event repeat.
		if ( $_REQUEST['event_id'] === 'new' )
		{
			echo '<tr><td>
				<input name="REPEAT" id="REPEAT" value="0" maxlength="3" size="1" type="number" min="0" />&nbsp;' . _( 'Days' ) .
				FormatInputTitle( _( 'Event Repeat' ), 'REPEAT' ) .
			'</td></tr>';
		}

		// Hook.
		do_action( 'School_Setup/Calendar.php|event_field' );


		// FJ bugfix SQL bug value too long for type character varying(50).
		echo '<tr><td>' .
			TextInput(
				issetVal( $RET[1]['TITLE'], '' ),
				'values[TITLE]',
				_( 'Title' ),
				'required size="20" maxlength="50"'
			) .
		'</td></tr>';

		if ( ! empty( $RET[1]['COURSE'] ) )
		{
			echo '<tr><td>' .
				NoInput( $RET[1]['COURSE'], _( 'Course' ) ) .
			'</td></tr>';
		}

		if ( ! empty( $RET[1]['STAFF_ID'] ) )
		{
			echo '<tr><td>' .
				TextInput( $RET[1]['STAFF_ID'], 'values[STAFF_ID]', _( 'Teacher' ) ) .
			'</td></tr>';
		}

		echo '<tr><td>' .
			TextAreaInput( issetVal( $RET[1]['DESCRIPTION'], '' ), 'values[DESCRIPTION]', _( 'Notes' ) ) .
		'</td></tr>';

		if ( AllowEdit() )
		{
			echo '<tr><td colspan="2">' . SubmitButton( _( 'Save' ), 'button' );

			if ( $_REQUEST['event_id'] !== 'new' )
			{
				echo SubmitButton( _( 'Delete' ), 'button', '' );
			}

			echo '</td></tr>';
		}

		echo '</table>';

		PopTable( 'footer' );

		if ( ! empty( $_REQUEST['event_id'] ) )
			echo '</form>';

		// Unset button & values & redirect URL.
		RedirectURL( array( 'button', 'values' ) );
	}
}

// List Events
if ( $_REQUEST['modfunc'] === 'list_events' )
{
	$start_date = RequestedDate( 'start', '' );

	if ( ! $start_date )
	{
		$min_date = DBGet( "SELECT min(SCHOOL_DATE) AS MIN_DATE
			FROM ATTENDANCE_CALENDAR
			WHERE SYEAR='" . UserSyear() . "'
			AND SCHOOL_ID='" . UserSchool() . "'" );

		if ( isset( $min_date[1]['MIN_DATE'] ) )
		{
			$start_date = $min_date[1]['MIN_DATE'];
		}
		else
			$start_date = date( 'Y-m' ) . '-01';
	}

	$end_date = RequestedDate( 'end', '' );

	if ( ! $end_date )
	{
		$max_date = DBGet( "SELECT max(SCHOOL_DATE) AS MAX_DATE
			FROM ATTENDANCE_CALENDAR
			WHERE SYEAR='" . UserSyear() . "'
			AND SCHOOL_ID='" . UserSchool() . "'" );

		if ( isset( $max_date[1]['MAX_DATE'] ) )
		{
			$end_date = $max_date[1]['MAX_DATE'];
		}
		else
			$end_date = DBDate();
	}

	echo '<form action="Modules.php?modname=' . $_REQUEST['modname'] . '&modfunc=' . $_REQUEST['modfunc'] . '&month=' . $_REQUEST['month'] . '&year=' . $_REQUEST['year'] . '" method="POST">';

	DrawHeader( '<a href="Modules.php?modname=' . $_REQUEST['modname'] . '&month=' . $_REQUEST['month'] . '&year=' . $_REQUEST['year'] . '" >' . _( 'Back to Calendar' ) . '</a>' );

	DrawHeader(
		_( 'Timeframe' ) . ': ' .
		PrepareDate( $start_date, '_start', false ) . ' ' .
		_( 'to' ) . ' ' . PrepareDate( $end_date, '_end', false ) . ' ' .
		Buttons( _( 'Go' ) )
	);


	$functions = array( 'SCHOOL_DATE' => 'ProperDate', 'DESCRIPTION' => 'makeTextarea' );

	$events_RET = DBGet( "SELECT ID,SCHOOL_DATE,TITLE,DESCRIPTION
		FROM CALENDAR_EVENTS
		WHERE SCHOOL_DATE BETWEEN '" . $start_date . "' AND '" . $end_date . "'
		AND SYEAR='" . UserSyear() . "'
		AND SCHOOL_ID='" . UserSchool() . "'", $functions );

	$column_names = array(
		'SCHOOL_DATE' => _( 'Date' ),
		'TITLE' => _('Event'),
		'DESCRIPTION' => _( 'Description' )
	);

	ListOutput( $events_RET, $column_names, 'Event', 'Events');

	echo '</form>';
}

// Display Calendar View.
if ( ! $_REQUEST['modfunc'] )
{

	echo ErrorMessage( $error );

	$last = 31;

	while( ! checkdate( $_REQUEST['month'], $last, $_REQUEST['year'] ) )
	{
		$last--;
	}

	$first_day_month = $_REQUEST['year'] . '-' . $_REQUEST['month'] . '-01';

	$last_day_month = $_REQUEST['year'] . '-' . $_REQUEST['month'] . '-' . $last;

	$calendar_SQL = "SELECT SCHOOL_DATE,MINUTES,BLOCK
		FROM ATTENDANCE_CALENDAR
		WHERE SCHOOL_DATE BETWEEN '" . $first_day_month . "'
		AND '" . $last_day_month . "'
		AND SYEAR='" . UserSyear() . "'
		AND SCHOOL_ID='" . UserSchool() . "'
		AND CALENDAR_ID='" . $_REQUEST['calendar_id'] . "'";

	$calendar_RET = DBGet( $calendar_SQL, array(), array( 'SCHOOL_DATE' ) );

	$update_calendar = false;

	// Update School Day minutes
	if ( AllowEdit()
		&& isset( $_REQUEST['minutes'] ) )
	{
		foreach ( (array) $_REQUEST['minutes'] as $date => $minutes )
		{
			// Fix SQL error when all-day checked & minutes.
			if ( ! empty( $_REQUEST['all_day'][ $date ] ) )
			{
				continue;
			}

			if ( ! empty( $calendar_RET[ $date ] ) )
			{
				//if ( $minutes!='0' && $minutes!='')
				//FJ fix bug MINUTES not numeric
				if ( intval( $minutes ) > 0 )
				{
					DBQuery( "UPDATE ATTENDANCE_CALENDAR
						SET MINUTES='" . intval( $minutes ) . "'
						WHERE SCHOOL_DATE='" . $date . "'
						AND SYEAR='" . UserSyear() . "'
						AND SCHOOL_ID='" . UserSchool() . "'
						AND CALENDAR_ID='" . $_REQUEST['calendar_id'] . "'" );
				}
				else
				{
					DBQuery( "DELETE FROM ATTENDANCE_CALENDAR
						WHERE SCHOOL_DATE='" . $date . "'
						AND SYEAR='" . UserSyear() . "'
						AND SCHOOL_ID='" . UserSchool() . "'
						AND CALENDAR_ID='" . $_REQUEST['calendar_id'] . "'" );
				}

				$update_calendar = true;
			}
			//elseif ( $minutes!='0' && $minutes!='')
			//FJ fix bug MINUTES not numeric
			elseif ( intval( $minutes ) > 0 )
			{
				DBQuery( "INSERT INTO ATTENDANCE_CALENDAR
					(SYEAR,SCHOOL_ID,SCHOOL_DATE,CALENDAR_ID,MINUTES)
					values('" . UserSyear() . "','" . UserSchool() . "','" . $date . "','" . $_REQUEST['calendar_id'] . "','" . intval( $minutes ) . "')" );

				$update_calendar = true;
			}
		}

		// Unset minutes & redirect URL.
		RedirectURL( 'minutes' );
	}

	// Update All day school.
	if ( AllowEdit()
		&& isset( $_REQUEST['all_day'] ) )
	{
		foreach ( (array) $_REQUEST['all_day'] as $date => $yes )
		{
			if ( $yes === 'Y' )
			{
				if ( $calendar_RET[ $date ] )
				{
					DBQuery( "UPDATE ATTENDANCE_CALENDAR
						SET MINUTES='999'
						WHERE SCHOOL_DATE='" . $date . "'
						AND SYEAR='" . UserSyear() . "'
						AND SCHOOL_ID='" . UserSchool() . "'
						AND CALENDAR_ID='" . $_REQUEST['calendar_id'] . "'" );
				}
				else
				{
					DBQuery( "INSERT INTO ATTENDANCE_CALENDAR
						(SYEAR,SCHOOL_ID,SCHOOL_DATE,CALENDAR_ID,MINUTES)
						values('" . UserSyear() . "','" . UserSchool()."','" . $date . "','" . $_REQUEST['calendar_id'] . "','999')" );
				}

				$update_calendar = true;
			}
			elseif ( $calendar_RET[ $date ] )
			{
				DBQuery( "DELETE FROM ATTENDANCE_CALENDAR
					WHERE SCHOOL_DATE='" . $date . "'
					AND SYEAR='" . UserSyear() . "'
					AND SCHOOL_ID='" . UserSchool() . "'
					AND CALENDAR_ID='" . $_REQUEST['calendar_id'] . "'" );

				$update_calendar = true;
			}
		}

		// Unset all day & redirect URL.
		RedirectURL( 'all_day' );
	}

	// Update Blocks.
	if ( AllowEdit()
		&& isset( $_REQUEST['blocks'] ) )
	{
		foreach ( (array) $_REQUEST['blocks'] as $date => $block )
		{
			if ( $calendar_RET[ $date ] )
			{
				DBQuery( "UPDATE ATTENDANCE_CALENDAR
					SET BLOCK='" . $block . "'
					WHERE SCHOOL_DATE='" . $date . "'
					AND SYEAR='" . UserSyear() . "'
					AND SCHOOL_ID='" . UserSchool() . "'
					AND CALENDAR_ID='" . $_REQUEST['calendar_id'] . "'" );

				$update_calendar = true;
			}
		}

		// Unset blocks & redirect URL.
		RedirectURL( 'blocks' );
	}

	// Update Calendar RET
	if ( $update_calendar )
	{
		$calendar_RET = DBGet( $calendar_SQL, array(), array( 'SCHOOL_DATE' ) );
	}

	echo '<form action="Modules.php?modname=' . $_REQUEST['modname'] . '" method="POST">';

	// Admin Headers
	if ( AllowEdit() )
	{
		$title_RET = DBGet( "SELECT CALENDAR_ID,TITLE,DEFAULT_CALENDAR
			FROM ATTENDANCE_CALENDARS WHERE SCHOOL_ID='" . UserSchool() . "'
			AND SYEAR='" . UserSyear() . "'
			ORDER BY DEFAULT_CALENDAR ASC,TITLE" );

		$defaults = 0;

		foreach ( (array) $title_RET as $title )
		{
			$options[ $title['CALENDAR_ID'] ] = $title['TITLE'] .
				( $title['DEFAULT_CALENDAR'] === 'Y' ? ' (' . _( 'Default' ) . ')' : '' );

			if ( $title['DEFAULT_CALENDAR'] === 'Y' )
			{
				$defaults++;
			}
		}

		//FJ bugfix erase calendar onchange
		$calendar_onchange_URL = "'Modules.php?modname=" . $_REQUEST['modname'] . "&calendar_id='";

		$links = SelectInput(
			$_REQUEST['calendar_id'],
			'calendar_id',
			'<span class="a11y-hidden">' . _( 'Calendar' ) . '</span>',
			$options,
			false,
			' onchange="ajaxLink(' . $calendar_onchange_URL . ' + document.getElementById(\'calendar_id\').value);" ',
			false
		) .
		'<a href="Modules.php?modname=' . $_REQUEST['modname'] . '&modfunc=create" class="nobr">' .
			button( 'add' ) . _( 'Create new calendar' ) .
		'</a> | ' .
		'<a href="Modules.php?modname=' . $_REQUEST['modname'] . '&modfunc=create&calendar_id=' . $_REQUEST['calendar_id'] . '" class="nobr">' .
			_( 'Recreate this calendar' ) .
		'</a>&nbsp; ' .
		'<a href="Modules.php?modname=' . $_REQUEST['modname'] . '&modfunc=delete_calendar&calendar_id=' . $_REQUEST['calendar_id'] . '" class="nobr">' .
			button( 'remove' ) . _( 'Delete this calendar' ) .
		'</a>';
	}

	$list_events_URL = 'Modules.php?modname=' . $_REQUEST['modname'] . '&modfunc=list_events&month=' . $_REQUEST['month'] . '&year=' . $_REQUEST['year'];

	DrawHeader(
		PrepareDate( mb_strtoupper( $first_day_month ), '', false, array( 'M' => 1, 'Y' => 1, 'submit' => true ) ) .
		' <a href="' . $list_events_URL . '">' .
			_( 'List Events' ) .
		'</a>',
		SubmitButton()
	);

	if ( ! empty( $links ) )
	{
		DrawHeader( $links );
	}

	// @since 4.5 Calendars header hook.
	do_action( 'School_Setup/Calendar.php|header' );

	if ( AllowEdit()
		&& $defaults != 1 )
	{
		echo ErrorMessage(
			array( $defaults ?
				_( 'This school has more than one default calendar!' ) :
				_( 'This school does not have a default calendar!' )
			)
		);
	}

	if ( isset( $no_calendars_error ) )
	{
		// No calendars, die.
		echo ErrorMessage( $no_calendars_error, 'fatal' );
	}

	echo '<br />';

	// Get Events
	$events_RET = DBGet( "SELECT ID,SCHOOL_DATE,TITLE,DESCRIPTION
		FROM CALENDAR_EVENTS
		WHERE SCHOOL_DATE BETWEEN '" . $first_day_month . "'
		AND '" . $last_day_month . "'
		AND SYEAR='" . UserSyear() . "'
		AND SCHOOL_ID='" . UserSchool() . "'", array(), array( 'SCHOOL_DATE' ) );

	// Get Assignments
	$assignments_RET = null;

	if ( User( 'PROFILE' ) === 'parent'
		|| User( 'PROFILE' ) === 'student' )
	{

		$assignments_SQL = "SELECT ASSIGNMENT_ID AS ID,a.DUE_DATE AS SCHOOL_DATE,a.TITLE,'Y' AS ASSIGNED
			FROM GRADEBOOK_ASSIGNMENTS a,SCHEDULE s
			WHERE (a.COURSE_PERIOD_ID=s.COURSE_PERIOD_ID OR a.COURSE_ID=s.COURSE_ID)
			AND s.STUDENT_ID='" . UserStudentID() . "'
			AND (a.DUE_DATE BETWEEN s.START_DATE AND s.END_DATE OR s.END_DATE IS NULL)
			AND (a.ASSIGNED_DATE<=CURRENT_DATE OR a.ASSIGNED_DATE IS NULL)
			AND a.DUE_DATE BETWEEN '" . $first_day_month . "' AND '" . $last_day_month . "'";
	}
	elseif ( User( 'PROFILE' ) === 'teacher' )
	{
		$assignments_SQL = "SELECT ASSIGNMENT_ID AS ID,a.DUE_DATE AS SCHOOL_DATE,a.TITLE,
				CASE WHEN a.ASSIGNED_DATE<=CURRENT_DATE OR a.ASSIGNED_DATE IS NULL THEN 'Y' ELSE NULL END AS ASSIGNED
			FROM GRADEBOOK_ASSIGNMENTS a
			WHERE a.STAFF_ID='" . User( 'STAFF_ID' ) . "'
			AND a.DUE_DATE BETWEEN '" . $first_day_month . "' AND '" . $last_day_month . "'";
	}

	if ( isset( $assignments_SQL ) )
	{
		$assignments_RET = DBGet( $assignments_SQL, array(), array( 'SCHOOL_DATE' ) );
	}

	// Calendar Events onclick popup
	$popup_URL = 'Modules.php?modname=' . $_REQUEST['modname'] . '&modfunc=detail&year=' . $_REQUEST['year'] . '&month=' . $_REQUEST['month'];
?>
<script>
	var popupURL = <?php echo json_encode( $popup_URL ); ?>;

	function CalEventPopup(url) {
		popups.open( url, "scrollbars=yes,resizable=yes,width=500,height=400" );
	}
</script>
<?php

	if ( isset( $_REQUEST['_ROSARIO_PDF'] ) )
	{
		// Landscape PDF.
		$_SESSION['orientation'] = 'landscape';
	}

	// Calendar Header
	echo '<table id="calendar" class="width-100p valign-top">
		<thead><tr class="center">';

	echo '<th>' . _( 'Sunday' ) . '</th>' .
		'<th>' . _( 'Monday' ) . '</th>' .
		'<th>' . _( 'Tuesday' ) . '</th>' .
		'<th>' . _( 'Wednesday' ) . '</th>' .
		'<th>' . _( 'Thursday' ) . '</th>' .
		'<th>' . _( 'Friday' ) . '</th>' .
		'<th>' . _( 'Saturday' ) . '</th>';

	echo '</tr></thead><tbody><tr>';

	$return_counter = 0;

	// Skip until first Day of Month.
	$skip = date( "w", strtotime( $first_day_month ) );

	if ( $skip )
	{
		echo '<td colspan="' . $skip . '" class="calendar-skip">&nbsp;</td>';

		$return_counter = $skip;
	}

	// Days.
	for ( $i = 1; $i <= $last; $i++ )
	{
		$date = $_REQUEST['year'] . '-' . $_REQUEST['month'] . '-' . str_pad( $i, 2, '0', STR_PAD_LEFT );

		$minutes = isset( $calendar_RET[ $date ][1]['MINUTES'] ) ? $calendar_RET[ $date ][1]['MINUTES'] : 0;

		$events_date = issetVal( $events_RET[ $date ], array() );

		$assignments_date = issetVal( $assignments_RET[ $date ], array() );

		$day_classes = CalendarDayClasses( $date, $minutes );

		$day_inner_classes = CalendarDayClasses(
			$date,
			$minutes,
			$events_date,
			$assignments_date,
			'inner'
		);

		$day_number_classes = CalendarDayClasses(
			$date,
			$minutes,
			$events_date,
			$assignments_date,
			'number'
		);

		echo '<td class="calendar-day' . $day_classes . '">
			<table class="' . $day_inner_classes . '"><tr>';


		// Calendar Day number.
		echo '<td class="' . $day_number_classes . '">' . $i . '</td>
		<td class="width-100p align-right">';

		echo CalendarDayMinutesHTML( $date, $minutes );

		$block = empty( $calendar_RET[ $date ][1]['BLOCK'] ) ? '' : $calendar_RET[ $date ][1]['BLOCK'];

		echo CalendarDayBlockHTML( $date, $minutes, $block );

		echo '</td></tr>
			<tr><td colspan="2" class="calendar-event valign-top">';

		echo CalendarDayEventsHTML( $date, $events_date );

		echo CalendarDayAssignmentsHTML( $date, $assignments_date );

		echo '</td></tr><tr>';

		echo CalendarDayNewAssignmentHTML( $date, $assignments_date );

		echo CalendarDayRotationNumberHTML( $date, $minutes );

		echo '</tr></table></td>';

		$return_counter++;

		if ( $return_counter % 7 === 0 )
		{
			echo '</tr><tr>';
		}
	}

	// Skip from Last Day of Month until end of Calendar
	if ( $return_counter %7 !== 0 )
	{
		$skip = 7 - $return_counter % 7;

		echo '<td colspan="' . $skip . '" class="calendar-skip">&nbsp;</td>';
	}

	echo '</tr></tbody></table>';

	echo '<br /><div class="center">' . SubmitButton() . '</div>';
	echo '<br /><br /></form>';
}
